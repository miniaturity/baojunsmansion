import asyncio
import pygame

from game import *


async def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((SCR_WIDTH, SCR_HEIGHT))
    pygame.display.set_caption("Baojun's Haunted Mansion")
    clock = pygame.time.Clock()

    manager = GameManager(screen)

    while manager.running:
        dt = min(clock.tick(FPS) / 1000, 0.05)
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                manager.running = False

        manager.handle_events(events)
        manager.update(dt)
        manager.draw()
        pygame.display.flip()
        
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())