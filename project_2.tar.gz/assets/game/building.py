import random
from .consts import *
from .mansion import MazeMansion
from . import components as C





class Building:

    def __init__(self, config: SpawnConfig | None = None, seed: int | None = None, floor_count: int = 2) -> None:
        self.config = config or SpawnConfig()
        self.rng = random.Random(seed)
        self.floors = [MazeMansion(Vector2(GRID_W, GRID_H), seed=self.rng.randrange(2 ** 31), floor_index=i)
                       for i in range(floor_count)]
        self.start_cell = self.floors[0].start_cell
        sx, sy = self.start_cell
        far = [(x, y) for y in range(GRID_H) for x in range(GRID_W) if abs(x - sx) + abs(y - sy) >= 5]
        self.stairs_cell = self.rng.choice(far)          

        self.shape_digits = {s: self.rng.randint(0, 9) for s in SHAPES}
        self.shape_order = list(SHAPES)
        self.rng.shuffle(self.shape_order)
        self.code = [self.shape_digits[s] for s in self.shape_order]

        self._populate()



    def arrival_cell(self, floor: int) -> tuple[int, int]:

        return self.start_cell if floor == 0 else self.stairs_cell



    def _count(self, prob: float, slots: int, lo: int, hi: int) -> int:

        rolled = sum(self.rng.random() < prob for _ in range(slots))

        return max(lo, min(hi, rolled))



    def _populate(self) -> None:

        cfg, rng = self.config, self.rng

        sx, sy = self.start_cell

        tx, ty = self.stairs_cell



        

        start_room = self.floors[0].grid[sy][sx]

        start_room.components.append(C.ExitDoor(start_room, offset=(0, 24)))

        reserved = {(0, sx, sy)}

        for i, floor in enumerate(self.floors):

            room = floor.grid[ty][tx]

            room.components.append(C.Stairs(room, up=(i == 0)))

            reserved.add((i, tx, ty))



        free = [r for f in self.floors for r in f.all_rooms() if (r.floor, r.gx, r.gy) not in reserved]

        rng.shuffle(free)



        

        for _ in range(self._count(cfg.prob_library, len(free), 1, 1)):

            room = free.pop()

            room.name = "Library"

            room.components += [C.Bookshelf(room, offset=(0, -20)), C.Battery(room, offset=(0, 20))]

        for _ in range(self._count(cfg.prob_safe, len(free), 1, 1)):

            room = free.pop()

            room.components.append(C.Safe(room))

        for shape in SHAPES:

            for _ in range(self._count(cfg.prob_digit_floor, len(free), 1, 1)):

                room = free.pop()

                room.components.append(C.CodeDigit(room, shape, self.shape_digits[shape]))



        

        table = [("drawer", cfg.prob_drawer), ("closet", cfg.prob_closet), ("coin_pile", cfg.prob_coin_pile),

                 ("battery", cfg.prob_battery), ("cross", cfg.prob_cross)]

        for room in free:

            r, acc = rng.random(), 0.0

            for kind, p in table:

                acc += p

                if r < acc:

                    self._spawn(kind, room)

                    break



    def _spawn(self, kind: str, room) -> None:

        if kind == "drawer":

            if self.rng.random() < self.config.drawer_candy_chance:

                room.components.append(C.CandyPile(room))

            else:

                room.components.append(C.CoinDrawer(room))

        elif kind == "closet":

            room.components.append(C.Closet(room))

        elif kind == "coin_pile":

            room.components.append(C.CoinPile(room))

        elif kind == "battery":

            room.components.append(C.Battery(room))

        elif kind == "cross":

            room.components.append(C.Cross(room))