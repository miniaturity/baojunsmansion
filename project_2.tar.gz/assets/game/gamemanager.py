import random

import pygame

from .consts import *
from .building import Building
from .mansion import InteractableRoomComponent
from .components import Safe
from .player import Player
from .enemies import SmallGhost, BossGhost
from .markov import MarkovPredictor, dir_from_delta


class GameManager:
    """
    States: "play", "safe" (code-entry panel open, world keeps running), "lose", "win".
    Exposes the hooks the room components call: notify, emit_sound, open_safe, change_floor, win, rng, player.
    """

    def __init__(self, screen: pygame.Surface) -> None:
        self.screen = screen
        self.font = pygame.font.SysFont(None, 20)
        self.big_font = pygame.font.SysFont(None, 56)
        self.running = True
        self.debug = False
        self.fps = 0.0
        self.camera = Vector2()
        self.rng = random
        self.new_game()

    # ------------------------------------------------------------------ setup
    def new_game(self) -> None:
        self.building = Building(floor_count=FLOOR_COUNT)
        self.floors = self.building.floors
        self.player = Player(self.floors[0].cell_center(*self.building.start_cell))
        self.predictor = MarkovPredictor()
        self.last_cell = self.player_cell
        self.open_timer = 0.0
        self.state = "play"
        self.message, self.message_timer = "", 0.0
        self.prompt_target: InteractableRoomComponent | None = None
        self.safe_target: Safe | None = None
        self.safe_input: list[int] = []

        self.ghosts: list[SmallGhost] = []
        for f in range(len(self.floors)):
            ox, oy = self.building.start_cell if f == 0 else self.building.stairs_cell
            spots = [(x, y) for y in range(GRID_H) for x in range(GRID_W) if abs(x - ox) + abs(y - oy) >= 5]
            for cell in random.sample(spots, min(GHOSTS_PER_FLOOR, len(spots))):
                g = SmallGhost(f)
                g.place_in_cell(cell)
                self.ghosts.append(g)
        self.boss = BossGhost()
        self.entities = [self.player]
        self._update_camera()

    @property
    def mansion(self):
        """The floor the player is currently on."""
        return self.floors[self.player.floor]

    @property
    def player_cell(self) -> tuple[int, int]:
        return self.mansion.cell_of(self.player.position)

    # ------------------------------------------------------- component hooks
    def notify(self, text: str) -> None:
        self.message, self.message_timer = text, 2.5

    def emit_sound(self, point: Vector2, floor: int, radius_rooms: int, name: str = "") -> None:
        for g in self.ghosts:
            if g.floor == floor and (g.position - point).length() <= radius_rooms * ROOM_SIZE_PX:
                g.hear(self, point)

    def open_safe(self, safe) -> None:
        self.safe_target = safe
        self.safe_input = []
        self.state = "safe"

    def change_floor(self) -> None:
        p = self.player
        p.floor = (p.floor + 1) % len(self.floors)
        p.position = self.mansion.cell_center(*self.building.stairs_cell)
        p.invuln = max(p.invuln, 0.5)
        # The boss and the ambush model both lose track of you on a new floor.
        self.boss.deactivate()
        self.open_timer = 0.0
        self.predictor.reset_heading()
        self.last_cell = self.player_cell
        self.notify(f"Floor {p.floor + 1}")

    def win(self) -> None:
        self.state = "win"

    # ----------------------------------------------------------- interaction
    def _nearest_interactable(self) -> InteractableRoomComponent | None:
        p = self.player
        if p.hidden:
            return None
        m = self.mansion
        cx, cy = self.player_cell
        best, best_d = None, float("inf")
        for y in range(max(0, cy - 1), min(GRID_H, cy + 2)):
            for x in range(max(0, cx - 1), min(GRID_W, cx + 2)):
                for comp in m.grid[y][x].components:
                    if not isinstance(comp, InteractableRoomComponent) or not comp.can_interact(self):
                        continue
                    d = (comp.world_pos - p.position).length()
                    if d <= comp.interact_radius and d < best_d and m.line_of_sight(p.position, comp.world_pos):
                        best, best_d = comp, d
        return best

    def _interact(self) -> None:
        p = self.player
        if p.hidden:
            p.leave_hiding()
            return
        if self.prompt_target is not None:
            self.prompt_target.interact(self)

    def _update_components(self, dt: float) -> None:
        cx, cy = self.player_cell
        m = self.mansion
        for y in range(max(0, cy - 1), min(GRID_H, cy + 2)):
            for x in range(max(0, cx - 1), min(GRID_W, cx + 2)):
                for comp in m.grid[y][x].components:
                    comp.update(dt, self)

    # ------------------------------------------------------------ safe panel
    def _safe_key(self, e: pygame.event.Event) -> None:
        n = len(SHAPES)
        if e.key == pygame.K_ESCAPE:
            self.state = "play"
        elif e.key == pygame.K_BACKSPACE:
            if self.safe_input:
                self.safe_input.pop()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if len(self.safe_input) < n:
                self.notify(f"Enter all {n} digits.")
            elif self.safe_input == self.building.code:
                self.player.has_key = True
                if self.safe_target is not None:
                    self.safe_target.opened = True
                self.state = "play"
                self.notify("The safe swings open. You found the key!")
            else:
                self.safe_input = []
                self.notify("Wrong code.")
        elif e.unicode.isdigit() and len(self.safe_input) < n:
            self.safe_input.append(int(e.unicode))

    # ---------------------------------------------------------------- events
    def handle_events(self, events: list[pygame.event.Event]) -> None:
        for e in events:
            if e.type != pygame.KEYDOWN:
                continue
            if self.state == "safe":
                self._safe_key(e)
                continue
            if e.key == pygame.K_ESCAPE:
                self.running = False
            elif e.key == pygame.K_F3:
                self.debug = not self.debug
            elif e.key == pygame.K_r and self.state in ("lose", "win"):
                self.new_game()
                return
            elif e.key == pygame.K_e and self.state == "play":
                self._interact()
        if self.state == "play":
            for ent in self.entities:
                ent.handle_events(events)

    # ---------------------------------------------------------------- update
    def update(self, dt: float) -> None:
        self.fps = 1 / dt if dt > 0 else 0.0
        self.message_timer = max(0.0, self.message_timer - dt)
        if self.state in ("play", "safe"):
            if self.state == "play":
                for ent in self.entities:
                    ent.update(dt, self.mansion)
            else:
                self.player.invuln = max(0.0, self.player.invuln - dt)   # player is busy at the safe
            for g in self.ghosts:
                if g.floor == self.player.floor:       # ghosts on the other floor wait
                    g.update(dt, self)
            self.boss.update(dt, self)
            self._update_components(dt)
            self._track_player(dt)
            self._check_contacts()
            self.prompt_target = self._nearest_interactable() if self.state == "play" else None
        self._update_camera()
        if self.state == "play":
            self.player.aim(Vector2(pygame.mouse.get_pos()) + self.camera)

    def _track_player(self, dt: float) -> None:
        cell = self.player_cell
        if cell != self.last_cell:
            dx, dy = cell[0] - self.last_cell[0], cell[1] - self.last_cell[1]
            if abs(dx) + abs(dy) == 1:
                self.predictor.record(dir_from_delta(dx, dy) or "")
            else:
                self.predictor.reset_heading()
            self.last_cell = cell

        if not self.boss.active:
            room = self.mansion.room_at(self.player.position)
            if room and room.open_count() >= BOSS_OPEN_OPENINGS and not self.player.hidden:
                self.open_timer += dt
            else:
                self.open_timer = max(0.0, self.open_timer - dt * 0.5)
            if self.open_timer >= BOSS_OPEN_SECONDS:
                self.boss.activate(self)
                self.notify("Something huge is coming...")

    def _check_contacts(self) -> None:
        p = self.player
        if p.hidden or p.invuln > 0:
            return
        attackers = list(self.ghosts) + ([self.boss] if self.boss.present else [])
        for g in attackers:
            if g.stun > 0 or g.floor != p.floor:
                continue
            if (g.position - p.position).length() <= (g.size + p.size) / 2 - 2:
                if p.has_cross:
                    p.has_cross = False
                    g.stun = 3.0
                    p.invuln = HIT_INVULN_S
                    self.notify("The cross blocked the attack!")
                else:
                    p.take_damage(g.damage)
                    g.stun = 1.5
                    self.notify(f"-{g.damage} HP")
                    if g is self.boss:
                        self.boss.deactivate()
                        self.open_timer = 0.0
                if p.health <= 0:
                    self.state = "lose"
                return

    def _update_camera(self) -> None:
        center = Vector2(SCR_WIDTH / 2, SCR_HEIGHT / 2)
        target = self.player.position - center
        self.camera = Vector2(round(target.x), round(target.y))

    # ------------------------------------------------------------------ draw
    def draw(self) -> None:
        self.screen.fill(BG_COLOR)
        self.mansion.draw(self.screen, self.camera)
        for g in self.ghosts:
            if g.floor == self.player.floor:
                g.draw(self.screen, self.camera)
        if self.boss.present and self.boss.floor == self.player.floor:
            self.boss.draw(self.screen, self.camera)
        for ent in self.entities:
            ent.draw(self.screen, self.camera)
        self.player.flashlight.draw_darkness(self.screen, self.player.position, self.camera, self.mansion)
        self._draw_hud()
        if self.debug:
            self._draw_debug()
        if self.state == "safe":
            self._draw_safe()
        elif self.state == "lose":
            self._draw_end("BAOJUN GOT YOU", (220, 40, 50), "Press R to try again")
        elif self.state == "win":
            self._draw_end("YOU ESCAPED", (90, 220, 120), f"Coins: {self.player.coins}  -  Press R to play again")

    def _draw_end(self, title: str, color, subtitle: str) -> None:
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 170))
        self.screen.blit(veil, (0, 0))
        for text, font, dy in ((title, self.big_font, -20), (subtitle, self.font, 25)):
            img = font.render(text, True, color)
            self.screen.blit(img, img.get_rect(center=(SCR_WIDTH // 2, SCR_HEIGHT // 2 + dy)))

    def _text_right(self, text: str, y: int, color=(255, 255, 255)) -> None:
        img = self.font.render(text, True, color, (0, 0, 0))
        self.screen.blit(img, img.get_rect(topright=(SCR_WIDTH - 8, y)))

    def _draw_hud(self) -> None:
        p = self.player
        # health + battery
        pygame.draw.rect(self.screen, (40, 0, 0), (SCR_WIDTH - 126, 8, 118, 12))
        pygame.draw.rect(self.screen, (200, 30, 40), (SCR_WIDTH - 126, 8, int(118 * p.health / PLAYER_MAX_HEALTH), 12))
        pygame.draw.rect(self.screen, (30, 30, 0), (SCR_WIDTH - 126, 24, 118, 8))
        pygame.draw.rect(self.screen, (230, 210, 60), (SCR_WIDTH - 126, 24, int(118 * p.battery / 100), 8))

        self._text_right(f"Floor {p.floor + 1}/{len(self.floors)}   Coins: {p.coins}", 38)
        y = 54
        if p.has_key:
            self._text_right("KEY", y, (255, 220, 90)); y += 16
        if p.has_cross:
            self._text_right("CROSS", y, (255, 240, 170)); y += 16
        if p.hidden:
            self._text_right("HIDDEN", y, (150, 200, 255)); y += 16
        # code notes
        shapes = self.building.shape_order if p.order_known else list(SHAPES)
        for i, s in enumerate(shapes):
            if s in p.digits or p.order_known:
                label = f"{i + 1}. {s} = {p.digits.get(s, '?')}" if p.order_known else f"{s} = {p.digits[s]}"
                self._text_right(label, y, (230, 215, 160)); y += 16

        # interaction prompt + messages
        if p.hidden:
            prompt = "[E] Leave closet"
        else:
            prompt = self.prompt_target.prompt(self) if self.prompt_target else ""
        if prompt and self.state == "play":
            img = self.font.render(prompt, True, (255, 240, 160), (0, 0, 0))
            self.screen.blit(img, img.get_rect(midbottom=(SCR_WIDTH // 2, SCR_HEIGHT - 30)))
        if self.message_timer > 0:
            img = self.font.render(self.message, True, (255, 255, 255), (0, 0, 0))
            self.screen.blit(img, img.get_rect(midbottom=(SCR_WIDTH // 2, SCR_HEIGHT - 8)))

    def _draw_safe(self) -> None:
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 150))
        self.screen.blit(veil, (0, 0))
        box = pygame.Rect(0, 0, 360, 240)
        box.center = (SCR_WIDTH // 2, SCR_HEIGHT // 2)
        pygame.draw.rect(self.screen, (40, 44, 55), box, border_radius=6)
        pygame.draw.rect(self.screen, (170, 175, 190), box, 2, border_radius=6)

        def put(text, center, color=(255, 255, 255), font=None):
            img = (font or self.font).render(text, True, color)
            self.screen.blit(img, img.get_rect(center=center))

        p, n = self.player, len(SHAPES)
        put("SAFE", (box.centerx, box.top + 22), font=pygame.font.SysFont(None, 34))
        slot_w, gap = 56, 14
        x0 = box.centerx - (n * slot_w + (n - 1) * gap) // 2
        for i in range(n):
            r = pygame.Rect(x0 + i * (slot_w + gap), box.top + 70, slot_w, 56)
            pygame.draw.rect(self.screen, (15, 15, 20), r, border_radius=4)
            pygame.draw.rect(self.screen, (170, 175, 190), r, 1, border_radius=4)
            hint = self.building.shape_order[i] if p.order_known else "?"
            put(hint, (r.centerx, r.top - 10), (190, 190, 150))
            if i < len(self.safe_input):
                put(str(self.safe_input[i]), r.center, (120, 255, 140), self.big_font)
        put("Notes:", (box.centerx, box.top + 150), (230, 215, 160))
        known = [f"{s}={p.digits[s]}" for s in (self.building.shape_order if p.order_known else SHAPES) if s in p.digits]
        put("  ".join(known) if known else "(none found yet)", (box.centerx, box.top + 170), (230, 215, 160))
        if not p.order_known:
            put("The order of the shapes is unknown...", (box.centerx, box.top + 190), (190, 150, 150))
        put("Type digits   Enter: open   Backspace: erase   Esc: close", (box.centerx, box.bottom - 14), (170, 170, 170))

    def _cell_px(self, cell) -> Vector2:
        return Vector2((cell[0] + 0.5) * ROOM_SIZE_PX, (cell[1] + 0.5) * ROOM_SIZE_PX) - self.camera

    def _draw_debug(self) -> None:
        cam = (-int(self.camera.x), -int(self.camera.y))
        for wall in self.mansion.wall_rects:
            pygame.draw.rect(self.screen, (0, 255, 0), wall.move(cam), 1)
        poly = self.player.flashlight.last_polygon
        if self.player.flashlight.on and len(poly) > 2:
            pygame.draw.lines(self.screen, (255, 255, 0), True, [p - self.camera for p in poly], 1)
        pygame.draw.rect(self.screen, (0, 200, 255), self.player.rect.move(cam), 1)

        here = [g for g in self.ghosts if g.floor == self.player.floor]
        for g in here:
            pts = [g.position - self.camera] + [self._cell_px(c) for c in g.path]
            if len(pts) > 1:
                pygame.draw.lines(self.screen, (0, 255, 0), False, pts, 1)
            label = f"STATE: {g.state} | TARGET: {g.goal if g.goal else '-'}"
            img = self.font.render(label, True, (0, 255, 0), (0, 0, 0))
            self.screen.blit(img, img.get_rect(midbottom=(g.position.x - self.camera.x, g.position.y - self.camera.y - g.size)))

        b = self.boss
        if b.active:
            pts = [b.position - self.camera] + [self._cell_px(c) for c in b.path]
            for a, c in zip(pts, pts[1:]):
                n = max(1, int((c - a).length() // 8))
                for i in range(0, n, 2):
                    pygame.draw.line(self.screen, (255, 30, 30), a.lerp(c, i / n), a.lerp(c, min(1, (i + 1) / n)), 2)
            for cell, util in b.candidates:
                sq = pygame.Surface((ROOM_SIZE_PX - 10, ROOM_SIZE_PX - 10), pygame.SRCALPHA)
                sq.fill((255, 230, 0, 90))
                ctr = self._cell_px(cell)
                self.screen.blit(sq, sq.get_rect(center=(ctr.x, ctr.y)))
                txt = "-inf" if util == float("-inf") else f"{util:.0f}"
                img = self.font.render(txt, True, (255, 255, 255))
                self.screen.blit(img, img.get_rect(center=(ctr.x, ctr.y)))

        acc = self.predictor.accuracy
        near = min(here, key=lambda g: (g.position - self.player.position).length(), default=None)
        room = self.mansion.room_at(self.player.position)
        lines = [
            "[DEBUG PANEL]",
            f"FPS: {self.fps:.0f}",
            f"Room: {room.id() if room else 'n/a'}",
            f"Markov Accuracy: {acc * 100:.1f}%" if acc is not None else "Markov Accuracy: n/a",
            f"Active Transitions Recorded: {self.predictor.transitions}",
            f"Small Ghost Path Node Count: {len(near.path) if near else 0} nodes",
            f"Boss Recalculation Timer: {max(0, b.recalc_timer):.2f}s / {BOSS_RECALC_S:.2f}s" if b.active else
            f"Boss: dormant ({self.open_timer:.1f}s / {BOSS_OPEN_SECONDS:.0f}s in the open)",
            f"Safe code: {self.building.code}",
        ]
        for i, text in enumerate(lines):
            self.screen.blit(self.font.render(text, True, (255, 255, 255), (0, 0, 0)), (6, 6 + i * 16))