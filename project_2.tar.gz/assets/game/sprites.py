import pygame





class Sprite:

    def draw(self, surface: pygame.Surface, rect: pygame.Rect, angle: float = 0.0) -> None:

        raise NotImplementedError("draw fn not implemented for Sprite")





class SolidSprite(Sprite):

    def __init__(self, color: tuple[int, int, int]) -> None:

        self.color = color



    def draw(self, surface, rect, angle=0.0) -> None:

        pygame.draw.rect(surface, self.color, rect)





class SurfaceSprite(Sprite):

    def __init__(self) -> None:

        self._cache: dict[tuple[int, int], pygame.Surface] = {}



    def build(self, size: tuple[int, int]) -> pygame.Surface:

        raise NotImplementedError("build fn not implemented for SurfaceSprite")



    def draw(self, surface, rect, angle=0.0) -> None:

        key = (rect.w, rect.h)

        base = self._cache.get(key)

        if base is None:

            base = self._cache[key] = self.build(key)

        img = base if angle == 0 else pygame.transform.rotate(base, -angle)

        surface.blit(img, img.get_rect(center=rect.center))





class ImageSprite(SurfaceSprite):

    def __init__(self, path: str) -> None:

        super().__init__()

        self.path = path



    def build(self, size):

        img = pygame.image.load(self.path).convert_alpha()

        return pygame.transform.smoothscale(img, size)





class BunnySprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        fur, pink, dark = (235, 235, 235), (250, 190, 205), (20, 20, 20)



        def box(x, y, bw, bh):

            return pygame.Rect(int(w * x), int(h * y), int(w * bw), int(h * bh))



        pygame.draw.ellipse(s, fur, box(0.30, 0.04, 0.34, 0.20))

        pygame.draw.ellipse(s, fur, box(0.30, 0.76, 0.34, 0.20))

        pygame.draw.ellipse(s, pink, box(0.36, 0.09, 0.22, 0.10))

        pygame.draw.ellipse(s, pink, box(0.36, 0.81, 0.22, 0.10))

        pygame.draw.ellipse(s, fur, box(0.08, 0.22, 0.62, 0.56))

        pygame.draw.circle(s, (255, 255, 255), (int(w * 0.10), int(h * 0.5)), max(2, int(w * 0.09)))

        pygame.draw.circle(s, fur, (int(w * 0.72), int(h * 0.5)), int(h * 0.22))

        pygame.draw.circle(s, dark, (int(w * 0.80), int(h * 0.38)), max(1, int(w * 0.04)))

        pygame.draw.circle(s, dark, (int(w * 0.80), int(h * 0.62)), max(1, int(w * 0.04)))

        pygame.draw.circle(s, pink, (int(w * 0.93), int(h * 0.5)), max(1, int(w * 0.04)))

        return s



class GhostSprite(SurfaceSprite):

    """Little Baojun ghost; boss=True makes the big red-eyed one."""



    def __init__(self, boss: bool = False) -> None:

        super().__init__()

        self.boss = boss



    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        body = (205, 205, 235, 235) if self.boss else (235, 238, 250, 225)

        r = w // 2

        pygame.draw.circle(s, body, (w // 2, r), r)

        pygame.draw.rect(s, body, (0, r, w, int(h * 0.38)))

        bumps = 4 if self.boss else 3

        bw = w / bumps

        for i in range(bumps):

            pygame.draw.circle(s, body, (int(bw * (i + 0.5)), int(h * 0.88)), max(2, int(bw / 2)))

        eye = (200, 20, 20) if self.boss else (15, 15, 25)

        er = max(2, int(w * (0.09 if self.boss else 0.08)))

        pygame.draw.ellipse(s, eye, (int(w * 0.25), int(h * 0.28), er * 2, er * 3))

        pygame.draw.ellipse(s, eye, (int(w * 0.60), int(h * 0.28), er * 2, er * 3))

        pygame.draw.ellipse(s, eye, (int(w * 0.40), int(h * 0.58), int(w * 0.2), int(h * 0.16)))

        return s







def _r(w, h, x, y, bw, bh) -> pygame.Rect:

    return pygame.Rect(int(w * x), int(h * y), max(1, int(w * bw)), max(1, int(h * bh)))





class CoinPileSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        for cx, cy in [(.32, .68), (.68, .68), (.5, .5), (.3, .34), (.7, .34)]:

            pos, rad = (int(w * cx), int(h * cy)), max(2, int(w * .2))

            pygame.draw.circle(s, (245, 205, 55), pos, rad)

            pygame.draw.circle(s, (170, 125, 20), pos, rad, 1)

        return s





class CandyPileSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        cols = [(255, 105, 180), (90, 220, 130), (90, 200, 255), (255, 170, 60)]

        for i, (cx, cy) in enumerate([(.3, .65), (.7, .65), (.5, .4), (.5, .72)]):

            pos, rad = (int(w * cx), int(h * cy)), max(2, int(w * .17))

            pygame.draw.circle(s, cols[i], pos, rad)

            pygame.draw.circle(s, (255, 255, 255), (pos[0] - 1, pos[1] - 1), max(1, rad // 3))

        return s





class CrossSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (255, 235, 150), _r(w, h, .4, .05, .2, .9))

        pygame.draw.rect(s, (255, 235, 150), _r(w, h, .15, .3, .7, .2))

        pygame.draw.rect(s, (180, 140, 40), _r(w, h, .4, .05, .2, .9), 1)

        return s





class BatterySprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (60, 200, 90), _r(w, h, .2, .2, .6, .75), border_radius=2)

        pygame.draw.rect(s, (220, 220, 220), _r(w, h, .35, .05, .3, .15))

        pygame.draw.polygon(s, (255, 255, 255), [(int(w * .52), int(h * .3)), (int(w * .36), int(h * .58)),

                                                 (int(w * .5), int(h * .58)), (int(w * .44), int(h * .85)),

                                                 (int(w * .66), int(h * .5)), (int(w * .52), int(h * .5))])

        return s





class DigitSprite(SurfaceSprite):

    """A note: a shape on the left, the digit on the right."""



    def __init__(self, shape: str, digit: int) -> None:

        super().__init__()

        self.shape, self.digit = shape, digit



    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (228, 212, 160), s.get_rect(), border_radius=3)

        pygame.draw.rect(s, (120, 90, 40), s.get_rect(), 1, border_radius=3)

        ink = (110, 20, 30)

        cx, cy, r = int(w * .28), h // 2, max(3, int(w * .17))

        if self.shape == "circle":

            pygame.draw.circle(s, ink, (cx, cy), r)

        elif self.shape == "square":

            pygame.draw.rect(s, ink, (cx - r, cy - r, 2 * r, 2 * r))

        elif self.shape == "triangle":

            pygame.draw.polygon(s, ink, [(cx, cy - r), (cx - r, cy + r), (cx + r, cy + r)])

        else:

            pygame.draw.polygon(s, ink, [(cx, cy - r), (cx - r, cy), (cx, cy + r), (cx + r, cy)])

        font = pygame.font.SysFont(None, max(10, int(h * .8)))

        img = font.render(str(self.digit), True, (30, 20, 10))

        s.blit(img, img.get_rect(center=(int(w * .7), h // 2)))

        return s





class DrawerSprite(SurfaceSprite):

    def __init__(self, opened: bool = False) -> None:

        super().__init__()

        self.opened = opened



    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (112, 72, 38), _r(w, h, .05, .1, .9, .8), border_radius=2)

        pygame.draw.rect(s, (60, 35, 15), _r(w, h, .05, .1, .9, .8), 1, border_radius=2)

        if self.opened:

            pygame.draw.rect(s, (30, 18, 8), _r(w, h, .12, .18, .76, .3))

            pygame.draw.rect(s, (130, 85, 45), _r(w, h, .12, .5, .76, .3))

        else:

            for y in (.18, .5):

                pygame.draw.rect(s, (135, 90, 50), _r(w, h, .12, y, .76, .3))

                pygame.draw.circle(s, (230, 200, 90), (w // 2, int(h * (y + .15))), max(1, int(w * .05)))

        return s





class ClosetSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (88, 58, 34), _r(w, h, .12, .04, .76, .92), border_radius=2)

        pygame.draw.rect(s, (45, 28, 14), _r(w, h, .12, .04, .76, .92), 1, border_radius=2)

        pygame.draw.line(s, (45, 28, 14), (w // 2, int(h * .08)), (w // 2, int(h * .92)), 1)

        for x in (.42, .54):

            pygame.draw.circle(s, (230, 200, 90), (int(w * x), h // 2), max(1, int(w * .03)))

        return s





class SafeSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (92, 98, 112), _r(w, h, .08, .08, .84, .84), border_radius=3)

        pygame.draw.rect(s, (40, 44, 55), _r(w, h, .08, .08, .84, .84), 2, border_radius=3)

        pygame.draw.circle(s, (170, 175, 190), (w // 2, h // 2), int(w * .2))

        pygame.draw.circle(s, (40, 44, 55), (w // 2, h // 2), int(w * .2), 1)

        pygame.draw.line(s, (40, 44, 55), (w // 2, h // 2), (int(w * .6), int(h * .4)), 2)

        return s





class BookshelfSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (70, 44, 24), _r(w, h, .04, .08, .92, .84))

        cols = [(150, 40, 40), (40, 90, 150), (50, 120, 60), (170, 140, 50), (110, 60, 140)]

        for row in (.14, .5):

            for i in range(7):

                pygame.draw.rect(s, cols[i % 5], _r(w, h, .1 + i * .115, row, .09, .3))

        return s





class StairsSprite(SurfaceSprite):

    def __init__(self, up: bool = True) -> None:

        super().__init__()

        self.up = up



    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (45, 30, 22), s.get_rect(), border_radius=3)

        for i in range(5):

            shade = 90 + i * 25 if self.up else 215 - i * 25

            pygame.draw.rect(s, (shade, shade - 15, shade - 30), _r(w, h, .08, .08 + i * .17, .84, .15))

        cx = w // 2

        pts = [(cx, int(h * .25)), (cx - int(w * .18), int(h * .55)), (cx + int(w * .18), int(h * .55))]

        if not self.up:

            pts = [(x, h - y) for x, y in pts]

        pygame.draw.polygon(s, (255, 255, 255), pts)

        return s





class DoorSprite(SurfaceSprite):

    def build(self, size):

        w, h = size

        s = pygame.Surface(size, pygame.SRCALPHA)

        pygame.draw.rect(s, (62, 36, 20), _r(w, h, .2, .02, .6, .96), border_top_left_radius=int(w * .3),

                         border_top_right_radius=int(w * .3))

        pygame.draw.rect(s, (30, 16, 8), _r(w, h, .2, .02, .6, .96), 1, border_top_left_radius=int(w * .3),

                         border_top_right_radius=int(w * .3))

        pygame.draw.circle(s, (235, 200, 80), (int(w * .68), int(h * .55)), max(2, int(w * .06)))

        return s