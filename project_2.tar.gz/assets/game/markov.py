DIRS = ["U", "D", "L", "R"]

IDX = {d: i for i, d in enumerate(DIRS)}

VEC = {"U": (0, -1), "D": (0, 1), "L": (-1, 0), "R": (1, 0)}

OPPOSITE = {"U": "D", "D": "U", "L": "R", "R": "L"}





def dir_from_delta(dx: int, dy: int) -> str | None:

    if dx == 0 and dy == 0:

        return None

    if abs(dx) >= abs(dy):

        return "R" if dx > 0 else "L"

    return "D" if dy > 0 else "U"





class MarkovPredictor:

    """

    First-order Markov model over the 4 cardinal directions.

    A "step" is the player crossing into a neighbouring room (that is what the ambush plans around),

    so we record transitions between consecutive room-to-room directions.

    """



    def __init__(self) -> None:

        self.matrix = [[0] * 4 for _ in range(4)]   

        self.prev: str | None = None

        self.transitions = 0

        self.trials = 0

        self.hits = 0

        self._pending: str | None = None            



    def reset_heading(self) -> None:

        """Forget the current heading (e.g. after taking stairs) but keep what we've learned."""

        self.prev = None

        self._pending = None



    def record(self, new_dir: str) -> None:

        if self._pending is not None:

            self.trials += 1

            self.hits += int(self._pending == new_dir)

        if self.prev is not None:

            self.matrix[IDX[self.prev]][IDX[new_dir]] += 1

            self.transitions += 1

        self.prev = new_dir

        self._pending = self.predict_next()[0]



    def predict_next(self) -> tuple[str | None, float]:

        """(most likely next direction, its probability) from the row of the current heading."""

        if self.prev is None:

            return None, 0.0

        row = self.matrix[IDX[self.prev]]

        total = sum(row)

        if total == 0:

            return None, 0.0

        best = max(range(4), key=lambda i: row[i])

        return DIRS[best], row[best] / total



    def prob_of(self, direction: str | None) -> float:

        if direction is None or self.prev is None:

            return 0.0

        row = self.matrix[IDX[self.prev]]

        total = sum(row)

        return row[IDX[direction]] / total if total else 0.0



    @property

    def accuracy(self) -> float | None:

        return self.hits / self.trials if self.trials else None