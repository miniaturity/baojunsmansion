import random

import pygame

from .consts import *

from .sprites import Sprite, SolidSprite



DIRS = {

    "n": (0, -1, "s"),

    "s": (0, 1, "n"),

    "w": (-1, 0, "e"),

    "e": (1, 0, "w"),

}





class Room:

    def __init__(self, name: str, position: Vector2, floor: int = 0) -> None:

        self.name = name

        self.position = position

        self.floor = floor

        self.paths = {"n": True, "w": True, "e": True, "s": True}

        self.visited = False

        self.components: list[RoomComponent] = []



    @property

    def gx(self) -> int:

        return int(self.position.x)



    @property

    def gy(self) -> int:

        return int(self.position.y)



    def id(self) -> str:

        return f"{self.name}({self.gx},{self.gy})"



    def open_count(self) -> int:

        return sum(1 for wall in self.paths.values() if not wall)





class RoomComponent:

    """Anything sitting in a room. Pass sprite=/offset=/size= to restyle or reposition."""

    kind = "component"

    size = 26



    def __init__(self, room: Room, sprite: Sprite | None = None, offset=(0, 0), size: int | None = None) -> None:

        self.room = room

        self.offset = Vector2(offset)

        if size is not None:

            self.size = size

        self.active = True

        self.sprite = sprite or self.default_sprite()



    def default_sprite(self) -> Sprite:

        return SolidSprite((200, 0, 200))



    def current_sprite(self) -> Sprite | None:

        return self.sprite



    def id(self) -> str:

        return f"{self.kind}@{self.room.id()}"



    @property

    def world_pos(self) -> Vector2:

        return Vector2((self.room.gx + 0.5) * ROOM_SIZE_PX, (self.room.gy + 0.5) * ROOM_SIZE_PX) + self.offset



    def update(self, dt: float, game) -> None:

        pass



    def draw(self, screen: pygame.Surface, rect: pygame.Rect) -> None:

        sprite = self.current_sprite()

        if sprite is None or not self.active:

            return

        r = pygame.Rect(0, 0, self.size, self.size)

        r.center = (rect.centerx + int(self.offset.x), rect.centery + int(self.offset.y))

        sprite.draw(screen, r)





class InteractableRoomComponent(RoomComponent):

    """Press E while close enough."""

    interact_radius = 36



    def can_interact(self, game) -> bool:

        return self.active



    def prompt(self, game) -> str:

        return "[E] Interact"



    def interact(self, game) -> None:

        raise NotImplementedError("InteractableRoomComponent interact not implemented")





class MazeMansion:

    def __init__(self, size: Vector2, floor_sprite: Sprite | None = None,

                 wall_sprite: Sprite | None = None, seed: int | None = None, floor_index: int = 0) -> None:

        self.floor_index = floor_index

        self.size = size

        self.cols = int(size.x)

        self.rows = int(size.y)

        self.floor_sprite = floor_sprite or SolidSprite(FLOOR_COLOR)

        self.wall_sprite = wall_sprite or SolidSprite(WALL_COLOR)

        self.grid: list[list[Room]] = []

        self.wall_rects: list[pygame.Rect] = []

        self._wall_lookup: dict[tuple[int, int], list[pygame.Rect]] = {}

        self.create_maze(seed)



    @property

    def start_cell(self) -> tuple[int, int]:

        return self.cols // 2, self.rows - 1



    def all_rooms(self) -> list[Room]:

        return [r for row in self.grid for r in row]



    def cell_center(self, gx: int, gy: int) -> Vector2:

        return Vector2((gx + 0.5) * ROOM_SIZE_PX, (gy + 0.5) * ROOM_SIZE_PX)



    def room_at(self, world_pos: Vector2) -> Room | None:

        gx, gy = int(world_pos.x // ROOM_SIZE_PX), int(world_pos.y // ROOM_SIZE_PX)

        if 0 <= gx < self.cols and 0 <= gy < self.rows:

            return self.grid[gy][gx]

        return None



    def _neighbors(self, room: Room):

        for d, (dx, dy, opp) in DIRS.items():

            nx, ny = room.gx + dx, room.gy + dy

            if 0 <= nx < self.cols and 0 <= ny < self.rows:

                yield d, self.grid[ny][nx]



    def create_maze(self, seed: int | None = None) -> None:

        rng = random.Random(seed)

        self.grid = [[Room("Room", Vector2(x, y), self.floor_index) for x in range(self.cols)] for y in range(self.rows)]



        sx, sy = self.start_cell

        current = self.grid[sy][sx]

        current.visited = True

        stack: list[Room] = []



        while True:

            options = [(d, n) for d, n in self._neighbors(current) if not n.visited]

            if options:

                d, nxt = rng.choice(options)

                current.paths[d] = False

                nxt.paths[DIRS[d][2]] = False

                stack.append(current)

                current = nxt

                current.visited = True

            elif stack:

                current = stack.pop()

            else:

                break



        for row in self.grid:

            for room in row:

                if room.open_count() == 1 and rng.random() < DEAD_END_BREAK_CHANCE:

                    walls = [(d, n) for d, n in self._neighbors(room) if room.paths[d]]

                    if walls:

                        d, n = rng.choice(walls)

                        room.paths[d] = False

                        n.paths[DIRS[d][2]] = False



        self._build_walls()



    def _build_walls(self) -> None:

        s, t = ROOM_SIZE_PX, WALL_THICKNESS

        rects: list[pygame.Rect] = []

        for row in self.grid:

            for r in row:

                x0, y0 = r.gx * s, r.gy * s

                if r.paths["n"]:

                    rects.append(pygame.Rect(x0 - t // 2, y0 - t // 2, s + t, t))

                if r.paths["w"]:

                    rects.append(pygame.Rect(x0 - t // 2, y0 - t // 2, t, s + t))

                if r.gy == self.rows - 1 and r.paths["s"]:

                    rects.append(pygame.Rect(x0 - t // 2, y0 + s - t // 2, s + t, t))

                if r.gx == self.cols - 1 and r.paths["e"]:

                    rects.append(pygame.Rect(x0 + s - t // 2, y0 - t // 2, t, s + t))

        self.wall_rects = rects



        self._wall_lookup = {}

        for rect in rects:

            for cx, cy in self._cells_overlapping(rect):

                self._wall_lookup.setdefault((cx, cy), []).append(rect)



    def _cells_overlapping(self, rect: pygame.Rect):

        x0 = max(0, rect.left // ROOM_SIZE_PX)

        x1 = min(self.cols - 1, (rect.right - 1) // ROOM_SIZE_PX)

        y0 = max(0, rect.top // ROOM_SIZE_PX)

        y1 = min(self.rows - 1, (rect.bottom - 1) // ROOM_SIZE_PX)

        for cy in range(y0, y1 + 1):

            for cx in range(x0, x1 + 1):

                yield cx, cy



    def walls_in_rect(self, rect: pygame.Rect) -> list[pygame.Rect]:

        out: list[pygame.Rect] = []

        for cell in self._cells_overlapping(rect):

            out.extend(self._wall_lookup.get(cell, ()))

        return out



    def point_hits_wall(self, p: Vector2) -> bool:

        cx, cy = int(p.x // ROOM_SIZE_PX), int(p.y // ROOM_SIZE_PX)

        if not (0 <= cx < self.cols and 0 <= cy < self.rows):

            return True

        return any(r.collidepoint(p.x, p.y) for r in self._wall_lookup.get((cx, cy), ()))



    

    def cell_of(self, point: Vector2) -> tuple[int, int]:

        return (min(max(int(point.x // ROOM_SIZE_PX), 0), self.cols - 1),

                min(max(int(point.y // ROOM_SIZE_PX), 0), self.rows - 1))



    def open_neighbors(self, cell: tuple[int, int]) -> list[tuple[int, int]]:

        room = self.grid[cell[1]][cell[0]]

        return [(cell[0] + dx, cell[1] + dy) for d, (dx, dy, _) in DIRS.items() if not room.paths[d]

                and 0 <= cell[0] + dx < self.cols and 0 <= cell[1] + dy < self.rows]



    def line_of_sight(self, a: Vector2, b: Vector2, step: float = 5.0) -> bool:

        d = b - a

        dist = d.length()

        if dist == 0:

            return True

        d /= dist

        t = step

        while t < dist:

            if self.point_hits_wall(a + d * t):

                return False

            t += step

        return True



    def draw(self, screen: pygame.Surface, camera: Vector2) -> None:

        cam = (-int(camera.x), -int(camera.y))

        view = screen.get_rect()

        for row in self.grid:

            for room in row:

                rect = pygame.Rect(room.gx * ROOM_SIZE_PX, room.gy * ROOM_SIZE_PX,

                                   ROOM_SIZE_PX, ROOM_SIZE_PX).move(cam)

                if not rect.colliderect(view):

                    continue

                self.floor_sprite.draw(screen, rect)

                for comp in room.components:

                    comp.draw(screen, rect)

        for wall in self.wall_rects:

            rect = wall.move(cam)

            if rect.colliderect(view):

                self.wall_sprite.draw(screen, rect)