import math
import pygame
from .consts import *


class Flashlight:
    def __init__(self, range_px: float = FLASHLIGHT_RANGE, fov_deg: float = FLASHLIGHT_FOV_DEG,
                 rays: int = FLASHLIGHT_RAYS) -> None:
        self.range = range_px
        self.fov = math.radians(fov_deg)
        self.rays = rays
        self.on = True
        self.suppressed = False
        self.angle = 0.0
        self.last_polygon: list[Vector2] = []
        self._dark: pygame.Surface | None = None

    def aim_at(self, origin: Vector2, target: Vector2) -> None:
        d = target - origin
        if d.length_squared() > 1:
            self.angle = math.atan2(d.y, d.x)

    def toggle(self) -> None:
        self.on = not self.on

    def _cast(self, origin: Vector2, direction: Vector2, mansion, step: float = 4.0) -> float:
        d = step
        while d <= self.range:
            if mansion.point_hits_wall(origin + direction * d):
                return min(self.range, d + WALL_THICKNESS / 2)
            d += step
        return self.range

    def compute_polygon(self, origin: Vector2, mansion) -> list[Vector2]:
        pts = [Vector2(origin)]
        for i in range(self.rays + 1):
            a = self.angle - self.fov / 2 + self.fov * i / self.rays
            direction = Vector2(math.cos(a), math.sin(a))
            pts.append(origin + direction * self._cast(origin, direction, mansion))
        self.last_polygon = pts
        return pts

    def draw_darkness(self, screen: pygame.Surface, origin: Vector2, camera: Vector2, mansion) -> None:
        if self._dark is None or self._dark.get_size() != screen.get_size():
            self._dark = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        dark = self._dark
        dark.fill((0, 0, 0, DARKNESS_ALPHA))

        o = origin - camera
        pygame.draw.circle(dark, (0, 0, 0, AMBIENT_ALPHA), (int(o.x), int(o.y)), AMBIENT_RADIUS)

        if self.on and not self.suppressed:
            self.draw_light(dark, origin, camera, mansion)
        screen.blit(dark, (0, 0))

    def draw_light(self, dark: pygame.Surface, origin: Vector2, camera: Vector2, mansion) -> None:
        o = origin - camera
        poly = [p - camera for p in self.compute_polygon(origin, mansion)]
        n = FLASHLIGHT_LAYERS
        for i in range(n):
            frac = 1.0 - 0.6 * i / (n - 1)
            alpha = int(DARKNESS_ALPHA * (0.85 - 0.70 * i / (n - 1)))
            pts = [o + (p - o) * frac for p in poly]
            pygame.draw.polygon(dark, (0, 0, 0, alpha), pts)