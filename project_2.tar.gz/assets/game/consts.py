from dataclasses import dataclass

import pygame



SCR_WIDTH = 500
SCR_HEIGHT = 500
FPS = 60



ROOM_SIZE_PX = 75
GRID_W = 10
GRID_H = 10
WALL_THICKNESS = 10
DEAD_END_BREAK_CHANCE = 0.5



PLAYER_SIZE = 22
PLAYER_SPEED = 130
PLAYER_MAX_HEALTH = 100



FLASHLIGHT_RANGE = 280
FLASHLIGHT_FOV_DEG = 55
FLASHLIGHT_RAYS = 48
FLASHLIGHT_LAYERS = 5
AMBIENT_RADIUS = 40
AMBIENT_ALPHA = 150
DARKNESS_ALPHA = 245


FLOOR_COLOR = (74, 48, 30)
WALL_COLOR = (122, 18, 32)
BG_COLOR = (0, 0, 0)



Vector2 = pygame.math.Vector2

SMALL_GHOST_COUNT = 4
GHOST_SIZE = 22
BOSS_SIZE = 46
GHOST_PATROL_SPEED = 45
GHOST_SEARCH_SPEED = 60
GHOST_CHASE_SPEED = 90          
BOSS_SPEED = 105
GHOST_DAMAGE = 25
BOSS_DAMAGE = 75
GHOST_ACQUIRE_ROOMS = 6         
GHOST_KEEP_ROOMS = 8            
GHOST_RECALC_S = 0.5            
GHOST_SEARCH_S = 3.0            
BOSS_RECALC_S = 0.5
BOSS_LOOKAHEAD = 3 
W_PROB = 100                    

W_DIST = 5
BOSS_OPEN_OPENINGS = 3
BOSS_OPEN_SECONDS = 6.0        
HIT_INVULN_S = 1.0
SOUND_RADIUS_ROOMS = 4





FLOOR_COUNT = 2
GHOSTS_PER_FLOOR = 3
CANDY_HEAL = 25
BATTERY_DRAIN_PER_S = 1.2        
SHAPES = ("circle", "square", "triangle", "diamond")





@dataclass

class SpawnConfig:
    prob_drawer: float = 0.20
    prob_closet: float = 0.15
    prob_coin_pile: float = 0.05
    prob_safe: float = 0.04          
    prob_cross: float = 0.01
    prob_battery: float = 0.07
    prob_digit_floor: float = 0.01   
    prob_library: float = 0.08       
    drawer_candy_chance: float = 0.50