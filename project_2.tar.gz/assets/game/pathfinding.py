import heapq
import itertools

Cell = tuple[int, int]

class Node:
    __slots__ = ("cell", "g", "f", "parent")

    def __init__(self, cell: Cell, g: int, f: int, parent: "Node | None") -> None:
        self.cell, self.g, self.f, self.parent = cell, g, f, parent

def manhattan(a: Cell, b: Cell) -> int:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def astar(mansion, start: Cell, goal: Cell) -> list[Cell] | None:
    if start == goal:
        return []
    tie = itertools.count()
    first = Node(start, 0, manhattan(start, goal), None)
    heap = [(first.f, next(tie), first)]
    best_g = {start: 0}
    closed: set[Cell] = set()
    while heap:
        _, _, node = heapq.heappop(heap)
        if node.cell in closed:
            continue
        if node.cell == goal:
            path = []
            while node.parent is not None:
                path.append(node.cell)
                node = node.parent
            path.reverse()
            return path
        closed.add(node.cell)
        for nb in mansion.open_neighbors(node.cell):
            if nb in closed:
                continue
            g = node.g + 1
            if g < best_g.get(nb, 1 << 30):
                best_g[nb] = g
                heapq.heappush(heap, (g + manhattan(nb, goal), next(tie), Node(nb, g, g + manhattan(nb, goal), node)))
    return None

def astar_cost(mansion, start: Cell, goal: Cell) -> float:
    path = astar(mansion, start, goal)
    return float("inf") if path is None else len(path)