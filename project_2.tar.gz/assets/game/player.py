import math

import pygame

from .consts import *

from .entity import Entity

from .flashlight import Flashlight

from .sprites import BunnySprite, Sprite





class Player(Entity):

    def __init__(self, position: Vector2, sprite: Sprite | None = None) -> None:

        super().__init__(position, sprite or BunnySprite(), size=PLAYER_SIZE)

        self.flashlight = Flashlight()

        self.health = PLAYER_MAX_HEALTH

        self.coins = 0

        self.floor = 0

        self.battery = 100.0

        self.hidden = False

        self.hide_spot = None

        self.has_cross = False

        self.has_key = False

        self.invuln = 0.0

        self.digits: dict[str, int] = {}      

        self.order_known = False              



    

    def take_damage(self, amount: int) -> None:

        self.health = max(0, self.health - amount)

        self.invuln = HIT_INVULN_S



    def heal(self, amount: int) -> None:

        self.health = min(PLAYER_MAX_HEALTH, self.health + amount)



    def restore_battery(self) -> None:

        self.battery = 100.0



    def hide_in(self, spot) -> None:

        self.hidden, self.hide_spot = True, spot

        self.position = Vector2(spot.world_pos)



    def leave_hiding(self) -> None:

        self.hidden, self.hide_spot = False, None



    

    def aim(self, world_target: Vector2) -> None:

        if self.hidden:

            return

        self.flashlight.aim_at(self.position, world_target)

        self.angle = math.degrees(self.flashlight.angle)



    def handle_events(self, events) -> None:

        for e in events:

            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and not self.hidden and self.battery > 0:

                self.flashlight.toggle()



    def update(self, dt: float, mansion=None) -> None:

        self.invuln = max(0.0, self.invuln - dt)

        if self.flashlight.on and not self.hidden:

            self.battery = max(0.0, self.battery - BATTERY_DRAIN_PER_S * dt)

            if self.battery <= 0:

                self.flashlight.on = False

        if self.hidden:

            return

        keys = pygame.key.get_pressed()

        move = Vector2(keys[pygame.K_d] - keys[pygame.K_a], keys[pygame.K_s] - keys[pygame.K_w])

        if move.length_squared() > 0:

            move = move.normalize() * PLAYER_SPEED * dt

            self._move_with_collision(move, mansion)



    def _move_with_collision(self, delta: Vector2, mansion) -> None:

        half = self.size / 2

        for axis in (0, 1):

            if delta[axis] == 0:

                continue

            self.position[axis] += delta[axis]

            if mansion is None:

                continue

            for wall in mansion.walls_in_rect(self.rect):

                if self.rect.colliderect(wall):

                    if axis == 0:

                        self.position.x = wall.left - half if delta.x > 0 else wall.right + half

                    else:

                        self.position.y = wall.top - half if delta.y > 0 else wall.bottom + half



    def draw(self, screen, camera) -> None:

        if not self.hidden:

            super().draw(screen, camera)