import pygame
from .consts import *
from .sprites import Sprite


class Entity:
    def __init__(self, position: Vector2, sprite: Sprite | None = None, size: int = ROOM_SIZE_PX // 3) -> None:
        self.position = Vector2(position)
        self.sprite = sprite
        self.size = size
        self.angle = 0.0

    @property
    def rect(self) -> pygame.Rect:
        h = self.size / 2
        return pygame.Rect(int(self.position.x - h), int(self.position.y - h), self.size, self.size)

    def draw(self, screen: pygame.Surface, camera: Vector2) -> None:
        if self.sprite is None:
            return
        screen_rect = self.rect.move(-int(camera.x), -int(camera.y))
        self.sprite.draw(screen, screen_rect, self.angle)

    def update(self, dt: float, mansion=None) -> None:
        pass

    def handle_events(self, events: list[pygame.event.Event]) -> None:
        pass