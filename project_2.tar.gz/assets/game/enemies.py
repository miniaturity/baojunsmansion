import random

import pygame

from .consts import *

from .entity import Entity

from .markov import DIRS, VEC, OPPOSITE, dir_from_delta

from .pathfinding import astar, astar_cost

from .sprites import GhostSprite





class Enemy(Entity):

    """Shared plumbing: cell-grid A* pathing + moving along the resulting path. Ghosts float, so no wall collision."""



    def __init__(self, sprite, size: int, floor: int, speed: float, damage: int) -> None:

        super().__init__(Vector2(), sprite, size)

        self.floor = floor

        self.speed = speed

        self.damage = damage

        self.path: list[tuple[int, int]] = []     

        self.goal: tuple[int, int] | None = None

        self.stun = 0.0



    @property

    def cell(self) -> tuple[int, int]:

        return (min(max(int(self.position.x // ROOM_SIZE_PX), 0), GRID_W - 1),

                min(max(int(self.position.y // ROOM_SIZE_PX), 0), GRID_H - 1))



    def place_in_cell(self, cell) -> None:

        self.position = Vector2((cell[0] + 0.5) * ROOM_SIZE_PX, (cell[1] + 0.5) * ROOM_SIZE_PX)

        self.path = []



    def set_goal(self, mansion, goal) -> None:

        """Re-path to `goal`. If we're mid-step we finish that step first so we don't jitter through walls."""

        self.goal = goal

        anchor = self.path[0] if self.path else self.cell

        route = astar(mansion, anchor, goal)

        if route is None:

            return

        self.path = ([anchor] if self.path else []) + route



    def move_toward(self, target: Vector2, dt: float) -> bool:

        d = target - self.position

        dist = d.length()

        step = self.speed * dt

        if dist <= step:

            self.position = Vector2(target)

            return True

        self.position += d / dist * step

        return False



    def follow_path(self, dt: float) -> bool:

        """Advance along the path. Returns True once there's nothing left to walk."""

        if self.path:

            c = self.path[0]

            if self.move_toward(Vector2((c[0] + 0.5) * ROOM_SIZE_PX, (c[1] + 0.5) * ROOM_SIZE_PX), dt):

                self.path.pop(0)

        return not self.path



    def hear(self, game, point: Vector2) -> None:

        pass



    def update(self, dt: float, game=None) -> None:   

        raise NotImplementedError("update fn not implemented for Enemy")











class SmallGhost(Enemy):

    PATROL, CHASE, SEARCH = "PATROL", "CHASE", "SEARCH"



    def __init__(self, floor: int, sprite=None) -> None:

        super().__init__(sprite or GhostSprite(), GHOST_SIZE, floor, GHOST_PATROL_SPEED, GHOST_DAMAGE)

        self.state = self.PATROL

        self.recalc_timer = 0.0

        self.last_known: Vector2 | None = None

        self.phase = "travel"            

        self.search_timer = 0.0

        self.prev_cell: tuple[int, int] | None = None



    def update(self, dt: float, game) -> None:

        if self.stun > 0:

            self.stun -= dt

            return

        mansion = game.floors[self.floor]

        player = game.player

        dist = (player.position - self.position).length()

        los = (
            (not player.hidden)
            and dist <= GHOST_KEEP_ROOMS * ROOM_SIZE_PX
            and mansion.line_of_sight(self.position, player.position)
        )

        sees_acquire = los and dist <= GHOST_ACQUIRE_ROOMS * ROOM_SIZE_PX



        if self.state == self.PATROL:

            if sees_acquire:

                self._acquire(game)

            else:

                self._patrol(dt, mansion)

        elif self.state == self.CHASE:

            if los:

                self._chase(dt, game, mansion)

            else:

                self.enter_search(game, self.last_known or player.position)

        else:  

            if sees_acquire:

                self._acquire(game)

            else:

                self._search(dt, mansion)



    

    def _acquire(self, game) -> None:
        self.state = self.CHASE

        self.speed = GHOST_CHASE_SPEED

        self.recalc_timer = 0.0



    def enter_search(self, game, point: Vector2) -> None:

        mansion = game.floors[self.floor]

        self.state = self.SEARCH

        self.speed = GHOST_SEARCH_SPEED

        self.phase = "travel"

        self.last_known = Vector2(point)

        self.set_goal(mansion, mansion.cell_of(point))



    def _to_patrol(self) -> None:

        self.state = self.PATROL

        self.speed = GHOST_PATROL_SPEED

        self.goal = None

        self.prev_cell = None



    def hear(self, game, point: Vector2) -> None:

        if self.state != self.CHASE:           

            self.enter_search(game, point)



    

    def _patrol(self, dt: float, mansion) -> None:

        if not self.path:

            nbrs = mansion.open_neighbors(self.cell)

            options = [n for n in nbrs if n != self.prev_cell] or nbrs

            if options:

                self.prev_cell = self.cell

                self.path = [random.choice(options)]

        self.follow_path(dt)



    def _chase(self, dt: float, game, mansion) -> None:

        player = game.player

        self.last_known = Vector2(player.position)

        self.recalc_timer -= dt

        pc = game.player_cell

        if self.recalc_timer <= 0:

            self.recalc_timer = GHOST_RECALC_S

            self.set_goal(mansion, pc)

        if self.cell == pc:

            self.path = []

            self.move_toward(player.position, dt)

        else:

            self.follow_path(dt)



    def _search(self, dt: float, mansion) -> None:

        if self.phase == "travel":

            if self.follow_path(dt):

                self.phase = "sweep"

                self.search_timer = GHOST_SEARCH_S

            return

        self.search_timer -= dt

        if not self.path:

            nbrs = mansion.open_neighbors(self.cell)

            if nbrs:

                self.path = [random.choice(nbrs)]

        self.follow_path(dt)

        if self.search_timer <= 0:

            self._to_patrol()











class BossGhost(Enemy):

    def __init__(self, sprite=None) -> None:

        super().__init__(sprite or GhostSprite(boss=True), BOSS_SIZE, 0, BOSS_SPEED, BOSS_DAMAGE)

        self.active = False

        self.arrival_timer = 0.0

        self.recalc_timer = 0.0

        self.candidates: list[tuple[tuple[int, int], float]] = []   

        self.ambushing = False



    @property

    def present(self) -> bool:

        return self.active and self.arrival_timer <= 0



    def activate(self, game) -> None:

        mansion = game.mansion

        pc = game.player_cell

        far = [(x, y) for y in range(mansion.rows) for x in range(mansion.cols)

               if abs(x - pc[0]) + abs(y - pc[1]) >= 6]

        self.floor = game.player.floor

        self.place_in_cell(random.choice(far or [(0, 0)]))

        self.active = True

        self.arrival_timer = 0.0

        self.recalc_timer = 0.0

        self.stun = 0.0



    def deactivate(self) -> None:

        self.active = False

        self.path = []

        self.candidates = []

        self.goal = None

        self.ambushing = False



    def update(self, dt: float, game) -> None:

        if not self.active:

            return

        if self.arrival_timer > 0:

            self.arrival_timer -= dt

            return

        if self.stun > 0:

            self.stun -= dt

            return

        mansion = game.floors[self.floor]

        self.recalc_timer -= dt

        if self.recalc_timer <= 0:

            self.recalc_timer = BOSS_RECALC_S

            self.plan(game, mansion)

        if self.cell == game.player_cell and not self.path:

            self.move_toward(game.player.position, dt)

        else:

            self.follow_path(dt)



    

    def _project(self, mansion, cell, direction: str, steps: int):

        """Walk up to `steps` cells along `direction`, stopping at walls."""

        x, y = cell

        dx, dy = VEC[direction]

        for _ in range(steps):

            if (x + dx, y + dy) not in mansion.open_neighbors((x, y)):

                break

            x, y = x + dx, y + dy

        return (x, y)



    def _candidates(self, mansion, proj, direction: str):

        """The projected cell plus up to two direct neighbours of it (ahead, behind, then sideways)."""

        out = [proj]

        nbrs = mansion.open_neighbors(proj)

        side = [d for d in DIRS if d not in (direction, OPPOSITE[direction])]

        for d in [direction, OPPOSITE[direction]] + side:

            dx, dy = VEC[d]

            c = (proj[0] + dx, proj[1] + dy)

            if c in nbrs and c not in out:

                out.append(c)

            if len(out) == 3:

                break

        return out



    def plan(self, game, mansion) -> None:

        pc = game.player_cell

        predictor = game.predictor

        direction, _ = predictor.predict_next()

        goal = pc

        self.candidates = []

        self.ambushing = False

        origin = self.path[0] if self.path else self.cell



        if direction is not None:

            proj = self._project(mansion, pc, direction, BOSS_LOOKAHEAD)

            best_u, best_c = None, None

            for c in self._candidates(mansion, proj, direction):

                p_target = predictor.prob_of(dir_from_delta(c[0] - pc[0], c[1] - pc[1]))

                cost = astar_cost(mansion, origin, c)

                util = W_PROB * p_target - W_DIST * cost       

                self.candidates.append((c, util))

                if best_u is None or util > best_u:

                    best_u, best_c = util, c

            if best_u is not None and best_u > 0:

                goal = best_c

                self.ambushing = True

            

        self.set_goal(mansion, goal)