"""All spawnable props from the design doc. Each takes sprite=/offset=/size= to restyle or reposition."""

from .consts import *

from .mansion import Room, RoomComponent, InteractableRoomComponent

from . import sprites as S







class PickupComponent(RoomComponent):

    touch_radius = 18



    def can_collect(self, game) -> bool:

        return True



    def collect(self, game) -> None:

        raise NotImplementedError("PickupComponent collect not implemented")



    def update(self, dt, game) -> None:

        p = game.player

        if not self.active or self.room.floor != p.floor or p.hidden:

            return

        if (self.world_pos - p.position).length() <= self.touch_radius and self.can_collect(game):

            self.collect(game)

            self.active = False





class CoinPile(PickupComponent):

    kind = "coin_pile"

    size = 26



    def default_sprite(self):

        return S.CoinPileSprite()



    def collect(self, game):

        n = game.rng.randint(30, 32)

        game.player.coins += n

        game.notify(f"+{n} coins")






class CandyPile(PickupComponent):

    kind = "candy_pile"

    size = 22



    def default_sprite(self):

        return S.CandyPileSprite()



    def can_collect(self, game):

        return game.player.health < PLAYER_MAX_HEALTH      



    def collect(self, game):

        game.player.heal(CANDY_HEAL)

        game.notify(f"Candy! +{CANDY_HEAL} HP")






class Cross(PickupComponent):

    kind = "cross"

    size = 20



    def default_sprite(self):

        return S.CrossSprite()



    def can_collect(self, game):

        return not game.player.has_cross



    def collect(self, game):

        game.player.has_cross = True

        game.notify("A holy cross. It will block one attack.")






class Battery(PickupComponent):

    kind = "battery"

    size = 18



    def default_sprite(self):

        return S.BatterySprite()



    def can_collect(self, game):

        return game.player.battery < 100



    def collect(self, game):

        game.player.restore_battery()

        game.notify("Flashlight battery restored")






class CodeDigit(PickupComponent):

    kind = "code_digit"

    size = 28



    def __init__(self, room: Room, shape: str, digit: int, **kw) -> None:

        self.shape, self.digit = shape, digit

        super().__init__(room, **kw)



    def default_sprite(self):

        return S.DigitSprite(self.shape, self.digit)



    def collect(self, game):

        game.player.digits[self.shape] = self.digit

        game.notify(f"A note: {self.shape} = {self.digit}")







class CoinDrawer(InteractableRoomComponent):

    kind = "drawer"

    size = 30



    def __init__(self, room: Room, opened_sprite=None, **kw) -> None:

        super().__init__(room, **kw)

        self.opened = False

        self.opened_sprite = opened_sprite or S.DrawerSprite(opened=True)



    def default_sprite(self):

        return S.DrawerSprite()



    def current_sprite(self):

        return self.opened_sprite if self.opened else self.sprite



    def can_interact(self, game):

        return self.active and not self.opened



    def prompt(self, game):

        return "[E] Open drawer"



    def interact(self, game):

        self.opened = True

        n = game.rng.randint(12, 15)

        game.player.coins += n

        game.notify(f"+{n} coins... but the drawer creaked loudly!")

        game.emit_sound(self.world_pos, self.room.floor, SOUND_RADIUS_ROOMS, "drawer")





class Closet(InteractableRoomComponent):

    kind = "closet"

    size = 30



    def default_sprite(self):

        return S.ClosetSprite()



    def prompt(self, game):

        return "[E] Hide in closet"



    def interact(self, game):

        game.player.hide_in(self)

        game.notify("You hide. Ghosts can't catch you in here.")





class Safe(InteractableRoomComponent):

    kind = "safe"

    size = 28



    def __init__(self, room: Room, **kw) -> None:

        super().__init__(room, **kw)

        self.opened = False



    def default_sprite(self):

        return S.SafeSprite()



    def can_interact(self, game):

        return self.active



    def prompt(self, game):

        return "[E] Safe (empty)" if self.opened else "[E] Enter safe code"



    def interact(self, game):

        if self.opened:

            game.notify("The safe is empty.")

        else:

            game.open_safe(self)





class Bookshelf(InteractableRoomComponent):

    """Library furniture: reveals the order of the shapes for the safe code."""

    kind = "bookshelf"

    size = 30



    def default_sprite(self):

        return S.BookshelfSprite()



    def prompt(self, game):

        return "[E] Read the shelf"



    def interact(self, game):

        game.player.order_known = True

        game.notify("A diagram on the shelf shows the order of the shapes.")






class Stairs(InteractableRoomComponent):

    kind = "stairs"

    size = 32



    def __init__(self, room: Room, up: bool, **kw) -> None:

        self.up = up

        super().__init__(room, **kw)



    def default_sprite(self):

        return S.StairsSprite(self.up)



    def prompt(self, game):

        return "[E] Go upstairs" if self.up else "[E] Go downstairs"



    def interact(self, game):

        game.change_floor()





class ExitDoor(InteractableRoomComponent):

    kind = "exit"

    size = 30



    def default_sprite(self):

        return S.DoorSprite()



    def prompt(self, game):

        return "[E] Unlock exit" if game.player.has_key else "[E] Exit (locked)"



    def interact(self, game):

        if game.player.has_key:

            game.win()

        else:

            game.notify("Locked. You need the key from the safe.")